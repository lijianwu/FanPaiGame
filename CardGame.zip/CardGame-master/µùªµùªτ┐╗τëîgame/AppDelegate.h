//
//  AppDelegate.h
//  旦旦翻牌game
//
//  Created by HUST on 2021/1/9.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic,strong)UIWindow *window;

@end

